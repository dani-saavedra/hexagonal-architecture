package com.filosofiadelsoftware.notification.events;

public enum EventType {
	CREATED, UPDATED, DELETED
}
