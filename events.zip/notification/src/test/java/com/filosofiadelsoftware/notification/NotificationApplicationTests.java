package com.filosofiadelsoftware.notification;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NotificationApplicationTests {

	@Test
	void contextLoads() {
	}

}
