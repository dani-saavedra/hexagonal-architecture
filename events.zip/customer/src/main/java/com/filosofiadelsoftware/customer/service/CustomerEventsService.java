package com.filosofiadelsoftware.customer.service;

import com.filosofiadelsoftware.customer.entity.Customer;
import com.filosofiadelsoftware.customer.events.CustomerCreatedEvent;
import com.filosofiadelsoftware.customer.events.Event;
import com.filosofiadelsoftware.customer.events.EventType;
import java.util.Date;
import java.util.UUID;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Component;

@Component
public class CustomerEventsService {


  private final KafkaTemplate<String, Event<?>> producer;

  @Value("${topic.notification.name}")
  private String topicCustomer;

  public CustomerEventsService(KafkaTemplate<String, Event<?>> producer) {
    this.producer = producer;
  }


  public void publish(Customer customer) {

    CustomerCreatedEvent created = new CustomerCreatedEvent();
    created.setData(customer);
    created.setId(UUID.randomUUID().toString());
    created.setType(EventType.CREATED);
    created.setDate(new Date());

    this.producer.send(topicCustomer, created);
  }


}
