package com.filosofiadelsoftware.customer.web;

import com.filosofiadelsoftware.customer.entity.Customer;
import com.filosofiadelsoftware.customer.service.CustomerService;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/customers")
public class CustomerController {
	
	private final CustomerService customerService;

	public CustomerController(CustomerService customerService) {
		this.customerService = customerService;
	}
	
	@PostMapping
	public Customer save(@RequestBody Customer customer) {
		return this.customerService.save(customer);
	}
	

}
