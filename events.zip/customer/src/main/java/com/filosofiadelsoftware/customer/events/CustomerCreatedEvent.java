package com.filosofiadelsoftware.customer.events;

import com.filosofiadelsoftware.customer.entity.Customer;
import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper = true)
public class CustomerCreatedEvent extends Event<Customer> {

}
