package com.filosofiadelsoftware.customer.events;

public enum EventType {
	CREATED, UPDATED, DELETED
}
